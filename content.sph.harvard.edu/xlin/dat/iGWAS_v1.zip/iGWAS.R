library(mixtools)
source("myEM.R")
source("PSeffect.R")
iGWAS<-function(
	SS=S.cc,		# SNPs
	MM=mu_M,		# DNA methylation (if not available, input rep(0,n))
	GG=mu_G,		# Gene expression
	YY=Y.cc,		# Dichotomous outcome
	MGMG=mu_MG,		# Methylation-by-expression interaction (if not available, input rep(0,n))
	XX=NA,			# Covariates
	ff,			# Family ID
	mm="pert",		# Methods for obtaining null dsitribution: "pert": perturbation; "davi": Davies' method
	weight2="lambda",	# Weights of SNP, DNA methylation and Gene expression
	aa=c(1,1,1,1,1),	# Pre-specified weights
	nn.pert=5000,		# Number of perturbation
	pp){			# Path: "sy", "sgy", or "all"

	Select<-rbind(c(T,T,T,T,T,T,T), c(T,T,T,T,T,T,F), c(T,T,T,T,F,F,F), c(T,T,T,F,F,F,F), c(T,F,F,F,F,F,F))

	if (mm=="pert" |mm=="both"){
		pall<-function(nn.pert, pert.app=FALSE){
			fit3<-PSeffect(S=SS, M=MM, G=GG, Y=YY, MG=MGMG, X=XX, select.p=Select[1,], weight=weight2, a=aa, n.pert=nn.pert, path=pp, fam=ff, method=mm, pert.app=pert.app)
			fit2<-PSeffect(S=SS, M=MM, G=GG, Y=YY, MG=MGMG, X=XX, select.p=Select[4,], weight=weight2, a=aa, n.pert=nn.pert, path=pp, fam=ff, method=mm, pert.app=pert.app)
			if (pp=="all") fit1<-PSeffect(S=SS, M=MM, G=GG, Y=YY, MG=MGMG, X=XX, select.p=Select[5,], weight=weight2, a=aa, n.pert=nn.pert, path=pp, fam=ff, method=mm, pert.app=pert.app)
		
			if (pp=="all"){
				pmin.obs<-min(fit1[[1]], fit2[[1]], fit3[[1]])
				pmin.nul<-apply(cbind(fit1[[2]], fit2[[2]], fit3[[2]]), 1, min)
			} else {
				pmin.obs<-min(fit2[[1]], fit3[[1]])
				pmin.nul<-apply(cbind(fit2[[2]], fit3[[2]]), 1, min)
			}
			if (pert.app){
				mix<-normalmixEM(qnorm(pmin.nul), lambda=c(0.3,0.4,0.3), mu=c(0,0,0), sigma=c(0.3,0.5,0.2), maxit=1000, eps=1e-4)
				pi<-mix$lambda
				mu<-mix$mu
				sd<-mix$sigma
				pval.omb<-pi[1]*pnorm((qnorm(pmin.obs)-mu[1])/sd[1])+pi[2]*pnorm((qnorm(pmin.obs)-mu[2])/sd[2])++pi[3]*pnorm((qnorm(pmin.obs)-mu[3])/sd[3])
			} else pval.omb<-mean(pmin.nul<pmin.obs)+0.5/nn.pert
		
			if (pp=="all"){
				pval<-list(pval.omb, fit1[[1]], fit2[[1]], fit3[[1]])
				names(pval)<-c("omnibus", "p_s", "p_sg", "p_sgc")
			} else {
				pval<-list(pval.omb, fit2[[1]], fit3[[1]])
				names(pval)<-c("omnibus", "p_sg", "p_sgc")
			}
			return(pval)
		}
		pval<-pall(nn.pert=nn.pert, pert.app=FALSE)
	}

	if (mm=="davi"){
		fit3<-PSeffect(S=SS, M=MM, G=GG, Y=YY, MG=MGMG, X=XX, select.p=Select[1,], weight=weight2, a=aa, path=pp, fam=ff, method=mm)
		fit2<-PSeffect(S=SS, M=MM, G=GG, Y=YY, MG=MGMG, X=XX, select.p=Select[4,], weight=weight2, a=aa, path=pp, fam=ff, method=mm)
		if (pp=="all") fit1<-PSeffect(S=SS, M=MM, G=GG, Y=YY, MG=MGMG, X=XX, select.p=Select[5,], weight=weight2, a=aa, path=pp, fam=ff, method=mm)
	
		if (pp=="all"){
			pval<-list(fit1[1], fit2[1], fit3[1])
			names(pval)<-c("p_s", "p_sg", "p_sgc")
		} else {
			pval<-list(fit2[1], fit3[1])
			names(pval)<-c("p_sg", "p_sgc")
		}
	}

	return(pval)

}
