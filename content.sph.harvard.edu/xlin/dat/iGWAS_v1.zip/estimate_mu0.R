source("ridge_gcv.R")
estimate.mu0<-function(
	S=S,
	M=M,
	G=G,
	Cmg=C.mg,
	Csm=C.sm,
	Csg=C.sg,
	Csmg=C.smg,
	Y=Y,
	X=X,
	select, 
	select.p
){
	## select what to fit in the null model AND which to penalize (select2)/which not to (select3)
	combo<-list(S, M, G, Cmg, Csm, Csg, Csmg)
	select[select.p==F]<-T
	select2<-intersect(which(select==F), c(1,5:7))
	select3<-intersect(which(select==F), 2:4)

	penal<-NULL; unpenal<-X
	for (i in select2) penal<-cbind(penal, combo[[i]])
	for (i in select3) unpenal<-cbind(unpenal, combo[[i]])
	x.til<-cbind(unpenal, penal)
	if (is.null(unpenal)) unpenal<-NA
	if (is.null(penal)){
		fit0<-glm(Y~unpenal, family=binomial)
		eta0<-predict(fit0)
		mu0<-exp(eta0)/(1+exp(eta0))
		I2<-0
	} else if (dim(penal)[2]<3){
		fit0<-glm(Y~unpenal+penal, family=binomial)
		eta0<-predict(fit0)
		mu0<-exp(eta0)/(1+exp(eta0))
		I2<-0
	} else {
		presv1<-apply(apply(unpenal, 2, cumsum), 2, sum)!=0; presv2<-apply(apply(penal, 2, cumsum), 2, sum)!=0	# 2
		unpenal<-unpenal[,presv1]; penal<-penal[,presv2]				# 2
		rid<-ridge_gcv(response=Y, penal=penal, unpenal=unpenal, cross.val="gcv")
		mu0<-rid$mu
		I2<-rid$I2
	}
	out<-list(mu0=mu0, I2=I2, x.til=x.til)
	return(out)
}

