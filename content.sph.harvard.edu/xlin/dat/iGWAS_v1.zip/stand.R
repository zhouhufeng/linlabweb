stand<-function(Z){
	z.sd<-apply(Z, 2, sd)
	z.m<-apply(Z, 2, mean)
	Z.st<-t((t(Z)-z.m)/z.sd)
	return(Z.st)
}
