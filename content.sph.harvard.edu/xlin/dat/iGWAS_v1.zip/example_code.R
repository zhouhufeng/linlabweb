ch<-21
source("iGWAS.R")

pheno<-read.table("pheno_com.txt", h=T, row.names=1)			# Read phenotype (case/control) data
snp<-read.table(paste("ch", ch, "_com.txt", sep=""), h=T, row.names=1)	# Read SNP data
exp<-read.table("exp_com.txt", h=T, row.names=1)			# Read gene expression data
pair<-read.table("eQTL_pairs.txt", h=T)					# Read eQTL results (containing eQTL SNPs for the gene)
pc4<-read.table("pc4.txt", h=T)						# Read PCs for populatrion strafication adjustment

pair.sub<-pair[pair$ch==ch,]
probe_list<-as.character(unique(pair.sub$probe))

i<-2							# index for expression probe
psel<-probe_list[i]					# expression probe
ssel<-as.character(pair.sub[pair.sub$probe==psel,]$snp)	# eQTL SNPs for the expression probe

ddast<-pheno$DDAST
age<-pheno$age
comp<-ddast!="x"
n<-sum(comp)

fam<-substring(rownames(pheno)[comp], 1, 4)		# Family ID
asthma<-as.numeric(ddast[comp])-1			# dichotomous outcome
cova<-cbind(rep(1, n), as.numeric(age[comp]))		
cova<-cbind(cova, as.matrix(pc4[comp,]))		# Covariates: n-by-q matrix (including intercept)
gene<-t(exp[psel, comp])				# Gene expression: n-by-1 matrix
sset<-t(snp[ssel, comp])				# SNP set: n-by-p matrix

pval.sy<-iGWAS(SS=sset, GG=gene, MM=rep(0, n), MGMG=rep(0, n), XX=cova, YY=asthma, ff=fam, pp="sy", nn.pert=5000)
pval.sgy<-iGWAS(SS=sset, GG=gene, MM=rep(0, n), MGMG=rep(0, n), XX=cova, YY=asthma, ff=fam, pp="sgy", nn.pert=5000)
pval.all<-iGWAS(SS=sset, GG=gene, MM=rep(0, n), MGMG=rep(0, n), XX=cova, YY=asthma, ff=fam, pp="all", nn.pert=5000)

