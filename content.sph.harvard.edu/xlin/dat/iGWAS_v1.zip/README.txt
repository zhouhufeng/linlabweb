This set of code is for 

1) dichotomous outcome
2) family design
3) 2 or 3 mediators

Reference: Huang YT et al. (2015) iGWAS. Genetic Epidemiology