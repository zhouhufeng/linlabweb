weight1<-function(
	S=S,
	M=M,
	G=G,
	Cmg=C.mg,
	Csm=C.sm,
	Csg=C.sg,
	Csmg=C.smg,
	Y=Y,
	X=X,
	mu0
){

	## calculate SS^T, GG^T, CC^T, mu0
	SSt<-S%*%t(S)
	GGt<-G%*%t(G)
	MMt<-M%*%t(M)
	CCmgt<-Cmg%*%t(Cmg)
	CCsmt<-Csm%*%t(Csm)
	CCsgt<-Csg%*%t(Csg)
	CCsmgt<-Csmg%*%t(Csmg)
	
	## calculate K
	kk<-mu0*(1-mu0)
	kii<--4*mu0^4+8*mu0^3-5*mu0^2+mu0
	K<-2*kk%*%t(kk)
	diag(K)<-kii	

	## calculate C3
	ci<-2*mu0^3-3*mu0^2+mu0
	C3<-diag(ci)

	## calculate W
	W<-diag(kk)

	## calculate I
	SS<-as.numeric(SSt)
	MM<-as.numeric(MMt)
	GG<-as.numeric(GGt)
	CCmg<-as.numeric(CCmgt)
	CCsm<-as.numeric(CCsmt)	
	CCsg<-as.numeric(CCsgt)	
	CCsmg<-as.numeric(CCsmgt)	
	KK<-as.numeric(K)
	
	Iss<-sum(SS*KK*SS)*0.25
	Imm<-sum(MM*KK*MM)*0.25
	Igg<-sum(GG*KK*GG)*0.25
	Img<-sum(CCmg*KK*CCmg)*0.25
	Ism<-sum(CCsm*KK*CCsm)*0.25
	Isg<-sum(CCsg*KK*CCsg)*0.25
	Ismg<-sum(CCsmg*KK*CCsmg)*0.25

	Is.m<-sum(SS*KK*MM)*0.25
	Is.g<-sum(SS*KK*GG)*0.25
	Is.mg<-sum(SS*KK*CCmg)*0.25
	Is.sm<-sum(SS*KK*CCsm)*0.25
	Is.sg<-sum(SS*KK*CCsg)*0.25
	Is.smg<-sum(SS*KK*CCsmg)*0.25

	Im.g<-sum(MM*KK*GG)*0.25
	Im.mg<-sum(MM*KK*CCmg)*0.25
	Im.sm<-sum(MM*KK*CCsm)*0.25
	Im.sg<-sum(MM*KK*CCsg)*0.25
	Im.smg<-sum(MM*KK*CCsmg)*0.25

	Ig.mg<-sum(GG*KK*CCmg)*0.25
	Ig.sm<-sum(GG*KK*CCsm)*0.25
	Ig.sg<-sum(GG*KK*CCsg)*0.25
	Ig.smg<-sum(GG*KK*CCsmg)*0.25

	Img.sm<-sum(CCmg*KK*CCsm)*0.25
	Img.sg<-sum(CCmg*KK*CCsg)*0.25
	Img.smg<-sum(CCmg*KK*CCsmg)*0.25

	Ism.sg<-sum(CCsm*KK*CCsg)*0.25
	Ism.smg<-sum(CCsm*KK*CCsmg)*0.25
	
	Isg.smg<-sum(CCsg*KK*CCsmg)*0.25

	Ia.s<-t(X)%*%C3%*%diag(SSt)*0.5
	Ia.m<-t(X)%*%C3%*%diag(MMt)*0.5
	Ia.g<-t(X)%*%C3%*%diag(GGt)*0.5
	Ia.mg<-t(X)%*%C3%*%diag(CCmgt)*0.5
	Ia.sm<-t(X)%*%C3%*%diag(CCsmt)*0.5
	Ia.sg<-t(X)%*%C3%*%diag(CCsgt)*0.5
	Ia.smg<-t(X)%*%C3%*%diag(CCsmgt)*0.5
	
	if (is.null(dim(X))){
		I.aa<-t(X)%*%W%*%(X)
		I.at<-cbind(Ia.s, Ia.m, Ia.g, Ia.mg, Ia.sm, Ia.sg, Ia.smg)
	} else {
		I.aa<-as.numeric(t(X)%*%W%*%(X))
		I.at<-c(Ia.s, Ia.m, Ia.g, Ia.mg, Ia.sm, Ia.sg, Ia.smg)
	}

	I.tt<-matrix(c(Iss,   Is.m,   Is.g,   Is.mg,  Is.sm,  Is.sg,  Is.smg, 
                     Is.m,  Imm,    Im.g,   Im.mg,  Im.sm,  Im.sg,  Im.smg,
                     Is.g,  Im.g,   Igg,    Ig.mg,  Ig.sm,  Ig.sg,  Ig.smg,
			   Is.mg, Im.mg,  Ig.mg,  Img,    Img.sm, Img.sg, Img.smg,
			   Is.sm, Im.sm,  Ig.sm,  Img.sm, Ism,    Ism.sg, Ism.smg,
			   Is.sg, Im.sg,  Ig.sg,  Img.sg, Ism.sg, Isg,    Isg.smg,
			   Is.smg,Im.smg, Ig.smg, Img.smg,Ism.smg,Isg.smg,Ismg), 7)

	## calculate efficient information and its inverse
#	I.til<-I.tt-(as.matrix(I.at))%*%solve(I.aa)%*%t(as.matrix(I.at))
	I.til<-I.tt
	a<-sqrt(1/diag(I.til))
	a<-a/a[1]
	return(a)

}
