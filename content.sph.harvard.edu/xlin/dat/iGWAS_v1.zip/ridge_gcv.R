library(penalized)

ridge_gcv<-function(
	response=Y.cc,
	penal=cbind(S.cc, SM.cc),
	unpenal=cbind(X.cc, M.cc),
	cross.val="gcv"
){

n<-length(response)
upp<-sqrt(n)/log(n)
x.til<-cbind(unpenal, penal)
dim.p<-dim(penal)[2]; dim.u<-dim(x.til)[2]-dim.p

if (cross.val=="gcv"){
	rang<-seq(upp/20, upp, by=upp/20)
	GCV<-NULL
	for (lambda in rang){
		fit<-penalized(response=response, penalized=penal, unpenalized=unpenal, lambda2=lambda)
		alphas<-coefficients(fit)
		eta.hat<-x.til%*%alphas
		mu.hat<-exp(eta.hat)/(1+exp(eta.hat))
		
		eps<-residuals(fit)
		Delta.inv<-diag(as.numeric(mu.hat*(1-mu.hat)))
		Delta<-diag(1/as.numeric(mu.hat*(1-mu.hat)))
		
		I2<-diag(c(rep(0, dim.u), rep(lambda, dim.p)))
		Omega<-t(x.til)%*%Delta.inv%*%x.til+I2
		H<-Delta.inv%*%(x.til)%*%solve(Omega)%*%t(x.til)
		h<-sum(diag(H))/n
		quad<-t(eps)%*%Delta%*%eps
		gcv<-quad/(n*(1-h)^2)
		GCV<-c(GCV, gcv)
	}
	lambda.op<-rang[which.min(GCV)]
	fit.op.gcv<-penalized(response=response, penalized=penal, unpenalized=unpenal, lambda2=lambda.op)
	mu<-fitted(fit.op.gcv)
	I2<-diag(c(rep(0, dim.u), rep(lambda.op, dim.p)))
	out<-list(mu=mu, I2=I2)
}

if (cross.val=="cv"){
	cv<-optL2(response=response, penalized=penal, unpenalized=unpenal, minlambda2=0, maxlambda2=upp, fold=10)
	fit.op.cv<-penalized(response=response, penalized=penal, unpenalized=unpenal, lambda2=cv$lambda)
	mu<-fitted(fit.op.cv)
	I2<-diag(c(rep(0, dim.u), rep(cv$lambda, dim.p)))
	out<-list(mu=mu, I2=I2)
}
return(out)

}
