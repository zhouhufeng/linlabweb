library(CompQuadForm)
source("stand.R")
source("lambda.R")
source("ridge_gcv.R")
source("estimate_mu0.R")
PSeffect<-function(

	S=S.cc,
	M=M.cc,
	G=G.cc,
	Y=Y.cc,
	MG,
	X=NA,				# if not NA, remember to include 1's for intercept
	fam,
	weight="lambda",
	a=c(1,1,1,1,1,1,1),
	select.p=c(T,T,T,F,F,F,F),
	path="sy",
	method="pert",
	pert.app=FALSE,
	n.pert=200){

	if (path=="sy") select=c(T,F,F,F,T,T,T)
	if (path=="sgy") select=c(F,F,T,T,F,T,T)
	if (path=="smy") select=c(F,T,T,T,T,T,T)
	if (path=="all") select=c(T,T,T,T,T,T,T)

	## calculate n and p; generate X and C
	n<-length(Y)
	p<-dim(S)[2]
	m<-length(unique(fam))
	if (is.na(sum(X))) X<-matrix(rep(1, n), nc=1)
	C.sg<-as.matrix(as.numeric(G)*S)
	C.sm<-as.matrix(as.numeric(M)*S)
	if (is.na(sum(MG))){
		C.mg<-as.matrix(as.numeric(M)*as.numeric(G))
		C.smg<-as.matrix(as.numeric(M)*as.numeric(G)*S)
	} else {
		C.mg<-MG
		C.smg<-as.matrix(as.numeric(MG)*S)
	}

	## standardize S, G and C
	if (length(unique(G))>2) G<-(G-mean(G))/sd(G)
	if (length(unique(M))>2) M<-(M-mean(M))/sd(M)
	if (length(unique(C.mg))>2) C.mg<-(C.mg-mean(C.mg))/sd(C.mg)
	S<-stand(S)
	if (length(unique(M))>2) C.sm<-stand(C.sm)
	if (length(unique(G))>2) C.sg<-stand(C.sg)
	if (length(unique(G))>2 & length(unique(M))>2 )C.smg<-stand(C.smg)

	## Estimate mu0
	estmu<-estimate.mu0(S=S, M=M, G=G, Cmg=C.mg, Csm=C.sm, Csg=C.sg, Csmg=C.smg, Y=Y, X=X, select=select, select.p=select.p)
	mu.0<-estmu$mu0
	W0.5<-diag(sqrt(mu.0*(1-mu.0)))

	## Calculate weights a
	if (weight=="lambda") a<-weight1(S=S, M=M, G=G, Cmg=C.mg, Csm=C.sm, Csg=C.sg, Csmg=C.smg, Y=Y, X=X, mu0=mu.0)
	a[is.infinite(a)]<-0

	offd<-0.25
	mat<-matrix(0, nrow=length(fam), ncol=length(fam))
	for (i in 1:length(fam)){
		for (j in 1:length(fam)){
			if (fam[i]==fam[j]) {
				mat[i,j]<-offd
			}
		}
	}
	diag(mat)<-1
	R.inv<-solve(mat)

	## Calculate Q
	sel<-select & select.p
	A.cent<-0
	if (sel[1]) A.cent<-A.cent+a[1]*S%*%t(S)
	if (sel[2]) A.cent<-A.cent+a[2]*M%*%t(M)
	if (sel[3]) A.cent<-A.cent+a[3]*G%*%t(G)
	if (sel[4]) A.cent<-A.cent+a[4]*C.mg%*%t(C.mg)
	if (sel[5]) A.cent<-A.cent+a[5]*C.sm%*%t(C.sm)
	if (sel[6]) A.cent<-A.cent+a[6]*C.sg%*%t(C.sg)
	if (sel[7]) A.cent<-A.cent+a[7]*C.smg%*%t(C.smg)
	W<-diag(mu.0*(1-mu.0))
	Q.hat<-(1/m)*t(Y-mu.0)%*%R.inv%*%A.cent%*%R.inv%*%(Y-mu.0)
	select2<-rep(sel, c(p, 1, 1, 1, p, p, p))
	Vall<-cbind(sqrt(a[1])*S, sqrt(a[2])*M, sqrt(a[3])*G, sqrt(a[4])*C.mg, sqrt(a[5])*C.sm, sqrt(a[6])*C.sg, sqrt(a[7])*C.smg)
	V<-cbind(Vall[,select2])
	V<-R.inv%*%V									# working
	Xtil<-estmu$x.til
	U<-cbind(Xtil, V)
	U<-U[, apply(apply(U, 2, cumsum), 2, sum)!=0]				# 2

#	CC<-1/m*t(U)%*%W0.5%*%R.inv%*%W0.5%*%U
	CC<-1/m*t(U)%*%W%*%U								# working
	q<-dim(Xtil)[2]-sum(apply(apply(Xtil, 2, cumsum), 2, sum)==0)		# 2
	Cvx<-CC[(q+1):(dim(U)[2]), 1:q]
	Cxx<-CC[1:q, 1:q]+estmu$I2
	q2<-dim(V)[2]-sum(apply(apply(V, 2, cumsum), 2, sum)==0)		# 2
	Av<-cbind(-Cvx%*%solve(Cxx), diag(1, q2))

	## perturbation ##
	if (method=="pert"|method=="both"){
#		ehalf<-(1/sqrt(m))*t(U)%*%R.inv
		ehalf<-(1/sqrt(m))*t(U)						# working
		QQ.0<-rep(0, n.pert)
		set.seed(1357+13)
		N.m<-rnorm(m*n.pert)
		N.m<-matrix(N.m, nc=m)
		N.ext<-matrix(NA, nc=n, nr=n.pert)
		for (f in 1:m) N.ext[, fam==unique(fam)[f]]<-N.m[, f]
		epsilon<-ehalf%*%((Y-mu.0)*t(N.ext))
		for (r in 1:dim(Av)[1]) QQ.0<-QQ.0+(Av[r,]%*%epsilon)^2
		QQ.0<-as.numeric(QQ.0)

		pval.qq0<-(n.pert-rank(QQ.0)+1)/n.pert
		pval.qq0[which.max(pval.qq0)]<-1-0.5/n.pert
		pval<-mean(QQ.0>Q.hat[1])

		if (pert.app){
			EQ.p<-mean(QQ.0)
			VQ.p<-var(QQ.0)
			kappa.p<-VQ.p/(2*EQ.p)
			nu.p<-2*(EQ.p)^2/VQ.p
			pval<-pchisq(Q.hat[1]/kappa.p, df=nu.p, lower.tail=FALSE)
		}

		Pval<-list(pval, pval.qq0)
	}

	## Davies' method ##
	if (method=="davi"|method=="both"){
#		D<-t(U)%*%W%*%U/m
		D<-CC
		svdob<-eigen(D, symmetric=TRUE)
		D0.5<-svdob$vectors%*%diag(sqrt(round(svdob$values, 6)))%*%t(svdob$vectors)
		DD<-eigen(t(D0.5)%*%t(Av)%*%Av%*%D0.5, symmetric=TRUE)$value
		pval<-davies(Q.hat, lambda=DD[abs(DD)>1e-6])$Qq

	}
	if (method=="both") Pval[[1]]<-pval

	if (method=="davi") return(pval)
	if (method=="pert"|method=="both") return(Pval)

}

