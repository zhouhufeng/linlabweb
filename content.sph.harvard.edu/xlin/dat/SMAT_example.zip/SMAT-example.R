library(SMAT)

###### A simulated example of analyzing case-control data ######

# Load a simulated case-control dataset 
data(simdat_caco)
# Run SMAT with unstructured working matrix
out = with(simdat_caco, SMAT(y, x, s, w, working = "unstr"))
# The 1-DF common effect test (SMAT) p-value for a SNP 
print(out$pvalue)
# The p-value of the test for the common effect (homogeneity) assumption
print(out$pvalue.common)
     
###### A simulated example of analyzing control-only data ######

# Load a simulated control-only dataset
data(simdat_co)
# Run SMAT with unstructured working matrix
out = with(simdat_co, SMAT(y, x, s, working = "unstr"))
# The 1-DF common effect test (SMAT) p-value for a SNP
print(out$pvalue)
# The p-value of the test for the common effect (homogeneity) assumption
print(out$pvalue.common)

###### Use PLINK binary data as inputs ######
# The PLINK binary data "sim20" (sim20.bed, sim20.bim, sim20.fam) contain the genotype
#  information of 20 SNPs for 2000 individuals from a cohort
# The phenotype file "pheno.txt" contains the phenotypes (columns 3-7) and the covariates 
#  (columns 8-9) for the 2000 individuals
# call SMAT is very easy with these files as inputs

# Using equal weights
fits=SMAT.plink(file="sim20",file.pheno="pheno.txt",col.pheno=3:7,col.covar=8:9,verbose=T)
# Output p-values
print(fits$pvalues)

# Using disease status and prevalence to calculate weights
fits=SMAT.plink(file="sim20",file.pheno="pheno.txt",col.pheno=3:7,col.covar=8:9,col.status=10,prev=0.1,verbose=T)
# Output p-values
print(fits$pvalues)

