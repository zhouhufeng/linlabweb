TEtest is an R package for conducting integrated analyses of a set of SNPs as well as a gene expression. The program is able to test the overall effect regardless it is from SNPs or gene expression. The testing procedure accommodates various candidate models: SNP-only model, main effect model and main effect plus interaction model. 

Reference: Huang YT, VanderWeele TJ and Lin X (2014). Joint analysis of SNP and gene expression data in genetic association studies of complex diseases. Annals of Applied Statistics 2014; 8:352-376. 

This set of code is for 

1) dichotomous outcome
2) 1 mediator
3) non-family design

