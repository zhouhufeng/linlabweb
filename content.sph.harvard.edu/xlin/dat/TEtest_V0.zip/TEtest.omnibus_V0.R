require(mixtools)
source("TEtest_V0.R")
TEtest.omnibus<-function(
	SS, 		# SNP (n-by-p matrix)
	GG, 		# gene expression (n-by-1 matrix)
	YY, 		# dichotomous outomce (n-by-1 vector)
	fam1, 		# 1:n (n=sample size)
	nn.pert=1000, 	# no. of perturbation
	normmix=FALSE	# omnibus-pvalue with gaussian mixture approximation
){
	fit1<-my.TEtest(S=SS, G=GG, Y=YY, fam=fam1, method="pert", n.pert=nn.pert,
		consider.gene=TRUE, consider.intx=TRUE)
	fit2<-my.TEtest(S=SS, G=GG, Y=YY, fam=fam1, method="pert", n.pert=nn.pert,
		consider.gene=TRUE, consider.intx=FALSE)
	fit3<-my.TEtest(S=SS, G=GG, Y=YY, fam=fam1, method="pert", n.pert=nn.pert, 
		consider.gene=FALSE, consider.intx=FALSE)
	pmin.obs<-min(fit1[[1]], fit2[[1]], fit3[[1]])
	pmin.nul<-apply(cbind(fit1[[2]], fit2[[2]], fit3[[2]]), 1, min)

	if (!normmix) pval.omb<-mean(pmin.nul<pmin.obs)

	if (normmix){
		mix<-normalmixEM(qnorm(pmin.nul), fast=TRUE, epsilon=1e-6)
		pi<-mix$lambda
		mu<-mix$mu
		sd<-mix$sigma
		pval.omb<-pi[1]*pnorm((qnorm(pmin.obs)-mu[1])/sd[1])+pi[2]*pnorm((qnorm(pmin.obs)-mu[2])/sd[2])
	}

	pval<-list(pval.omb, fit1[[1]], fit2[[1]], fit3[[1]])
	names(pval)<-c("omnibus", "p_sgc", "p_sg", "p_s")
	return(pval)
}
