weight1<-function(
	S=S.s.comp,
	G=as.matrix(g.s[nomiss]),
	C=C,
	Y=y.s[nomiss],
	X=X,
	consider.gene=TRUE,
	consider.intx=TRUE
){

	## calculate SS^T, GG^T, CC^T, mu0
	SSt<-S%*%t(S)
	GGt<-G%*%t(G)
	CCt<-C%*%t(C)
	fit0<-glm(Y~X, family=binomial)
	eta0<-predict(fit0)
	mu0<-exp(eta0)/(1+exp(eta0))

	## calculate K
	kk<-mu0*(1-mu0)
	kii<--4*mu0^4+8*mu0^3-5*mu0^2+mu0
	K<-2*kk%*%t(kk)
	diag(K)<-kii	

	## calculate C3
	ci<-2*mu0^3-3*mu0^2+mu0
	C3<-diag(ci)

	## calculate W
	W<-diag(kk)

	## calculate I
	SS<-as.numeric(SSt)
	GG<-as.numeric(GGt)
	CC<-as.numeric(CCt)	
	KK<-as.numeric(K)
	
	Iss<-sum(SS*KK*SS)*0.25
	Igg<-sum(GG*KK*GG)*0.25
	Icc<-sum(CC*KK*CC)*0.25
	Isg<-sum(SS*KK*GG)*0.25
	Isc<-sum(SS*KK*CC)*0.25
	Igc<-sum(GG*KK*CC)*0.25

	Ias<-t(X)%*%C3%*%diag(SSt)*0.5
	Iag<-t(X)%*%C3%*%diag(GGt)*0.5
	Iac<-t(X)%*%C3%*%diag(CCt)*0.5
	
	I.aa<-as.numeric(t(X)%*%W%*%(X))
	I.tt<-matrix(c(Iss, Isg, Isc, Isg, Igg, Igc, Isc, Igc, Icc), 3)
	I.at<-c(Ias, Iag, Iac)

	if (!consider.intx & consider.gene) {I.tt<-I.tt[1:2,1:2]; I.at<-I.at[1:2]}

	## calculate efficient information and its inverse
	I.til<-I.tt-I.at%*%solve(I.aa)%*%t(I.at)
	a<-sqrt(1/diag(I.til))
	a<-a/a[1]
	return(a)

}
