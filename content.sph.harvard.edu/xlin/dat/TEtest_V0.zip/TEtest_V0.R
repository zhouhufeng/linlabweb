require(CompQuadForm)
my.TEtest<-function(

	S=S.cc,			# SNP (n-by-p matrix); n=sample size, p=no. of SNPs
	G=G.cc,			# gene expression (n-by-1 matrix)
	Y=Y.cc,			# dichotomous outcome (n-by-1 vector)
	X=NA,			# covariates
	consider.gene=FALSE,	# (F,F)->SNP-only analysis; (T,F)->SNP/expression joint analysis (main effect only)
	consider.intx=FALSE,	# (T,T)->SNP/expression joint analysis (main effect plus interaction)
	weight="lambda",	# "lambda" or "specify"
	a=c(1,1,1),		# specify weights if weight="specify"
	R.star=NA,		
	fam=NA,			# 1:n (n=sample size)
	method="pert",		# "satt", "davies", or "pert"
	n.pert=1000,		# no. of perturbation
	pert.app=FALSE
){

	## calculate n and p; generate X and C
	n<-length(Y)
	p<-dim(S)[2]
	if (is.na(X)) X<-rep(1, n)
	C<-matrix(NA, nr=n, nc=p)
	if (consider.intx) for (i in 1:n) C[i,]<-G[i,]*S[i,]

	## standardize S, G and C
	G<-1*(G-mean(G))/sd(G)
	s.sd<-apply(S, 2, sd)
	s.m<-apply(S, 2, mean)
	S<-t((t(S)-s.m)/s.sd)
	c.sd<-apply(C, 2, sd)
	c.m<-apply(C, 2, mean)
	C<-t((t(C)-c.m)/c.sd)

	## Calculate weights a

	if (weight!="specify"){
		if (weight=="lambda") source("lambda.R")
		if (consider.gene) a<-weight1(S, G, C, Y, X, consider.gene, consider.intx)
	}

	## Calculate Q

	fit0<-glm(Y~X, family=binomial)
	eta0<-predict(fit0)
	mu.0<-exp(eta0)/(1+exp(eta0))
	A.cent<-S%*%t(S)
	if (consider.gene & !consider.intx) A.cent<-a[1]*A.cent+a[2]*G%*%t(G)
	if (consider.intx & consider.gene) A.cent<-a[1]*A.cent+a[2]*G%*%t(G)+a[3]*C%*%t(C)
#	Q<-t(Y-mu.0)%*%A.cent%*%(Y-mu.0)
			
	## Estimate R.star

	p<-dim(S)[2]
	offd<-0
	ff<-fam
	mat<-matrix(0, nrow=length(ff), ncol=length(ff))
	mat2<-matrix(0, nrow=length(ff), ncol=length(ff))
	for (i in 1:length(ff)){
		for (j in 1:length(ff)){
			if (ff[i]==ff[j]) {
				mat[i,j]<-offd
				mat2[i,j]<-offd
			}
		}
	}
	diag(mat)<-1
	diag(mat2)<-1
	R.star<-mat
	R<-mat2

	R.inv<-solve(R)
	W0.5<-diag(exp(eta0*0.5)/(1+exp(eta0)))


	## Satterthwaite method ##

	if (method=="satt"){
		svdr<-svd(R.inv)
		R.inv.5<-svdr$u%*%diag(sqrt(svdr$d))
	
		Q<-t(Y-mu.0)%*%R.inv%*%A.cent%*%R.inv%*%(Y-mu.0)
	
		W0<-W0.5^2
		h<-R.inv.5%*%W0.5%*%X
		H<-h%*%solve(t(h)%*%h)%*%t(h)
		A<-(diag(1, n)-H)%*%R.inv%*%W0.5%*%A.cent%*%W0.5%*%R.inv%*%(diag(1, n)-H)
		W.inv<-diag((1+exp(eta0))^2/exp(eta0))
		if (sum(is.na(R.star))) R.star<-diag(1, dim(A)[1])
		EQ<-sum(diag(A%*%R.star))
		VQ<-2*sum(diag(A%*%R.star%*%A%*%R.star))
		kappa<-VQ/(2*EQ)
		nu<-2*(EQ)^2/VQ
		pval<-pchisq(Q/kappa, df=nu, lower.tail=FALSE)
	
	}

	if (method=="davies"){

		m<-length(unique(fam))
		Q.hat<-(1/m)*t(Y-mu.0)%*%R.inv%*%A.cent%*%R.inv%*%(Y-mu.0)

		svdr<-svd(R.inv)
		R.inv.5<-svdr$u%*%diag(sqrt(svdr$d))
		DD<-eigen(W0.5%*%R.inv.5%*%A.cent%*%R.inv.5%*%W0.5/m, symmetric=TRUE)$value

		pval<-davies(Q.hat, lambda=DD[DD>1e-6])$res
	}


	## perturbation ##

	if (method=="pert"){
	
		m<-length(unique(fam))
		Q.hat<-(1/m)*t(Y-mu.0)%*%R.inv%*%A.cent%*%R.inv%*%(Y-mu.0)
		
		if (!consider.gene & !consider.intx) V<-S
		if ( consider.gene & !consider.intx) V<-cbind(S, sqrt(a[2])*G)
		if ( consider.gene &  consider.intx) V<-cbind(S, sqrt(a[2])*G, sqrt(a[3])*C)
		U<-cbind(X, V)
		CC<-1/m*t(U)%*%W0.5%*%R.inv%*%W0.5%*%U
		if (!is.null(dim(X))) {
			q<-dim(X)[2]
		} else {
			q<-1
		}
		Cvx<-CC[(q+1):(dim(U)[2]), 1:q]
		Cxx<-CC[1:q, 1:q]
		Av<-cbind(-Cvx%*%solve(Cxx), diag(1, dim(V)[2]))
		
		ehalf<-(1/sqrt(m))*t(U)
		QQ.0<-rep(0, n.pert)
		set.seed(1357+13)
		N.m<-rnorm(m*n.pert)
		N.m<-matrix(N.m, nc=m)

		epsilon<-ehalf%*%((Y-mu.0)*t(N.ext))
		for (r in 1:dim(Av)[1]) QQ.0<-QQ.0+(Av[r,]%*%epsilon)^2
		QQ.0<-as.numeric(QQ.0)

		pval.qq0<-(n.pert-rank(QQ.0)+1)/n.pert
		pval.qq0[which.max(pval.qq0)]<-1-0.5/n.pert

		if (!pert.app) pval<-mean(QQ.0>Q.hat[1])
		if (pert.app){
			EQ.p<-mean(QQ.0)
			VQ.p<-var(QQ.0)
			kappa.p<-VQ.p/(2*EQ.p)
			nu.p<-2*(EQ.p)^2/VQ.p
			pval<-pchisq(Q.hat[1]/kappa.p, df=nu.p, lower.tail=FALSE)
		}


		Pval<-list(pval, pval.qq0)

	}

	if (method!="pert") return(pval)
	if (method=="pert") return(Pval)
}
