vdiag <-
function(v) {
	nr = nrow(v)
	nc = ncol(v)
	mat = matrix(0,nrow=nr,ncol=nc*nr)
	for(i in 1:nrow(v)) {
		mat[i,(1:nc)+(i-1)*nc] = v[i,]
	}
	return(mat)
}
