SMAT.plink <-
function(file,file.pheno,col.pheno,col.covar=NULL,col.w=NULL,col.status=NULL,prev=NULL,working="unstr",conv=1e-4,maxiter=5e2,verbose=FALSE) {
  if(!file.exists(file.pheno)) stop(paste(file.bed," does not exist!",sep=""))
  pheno=read.table(file.pheno,header=T)
  
  file.bed=paste(file,".bed",sep="")
  if(!file.exists(file.bed)) stop(paste(file.bed," does not exist!",sep=""))
  file.bim=paste(file,".bim",sep="")
  if(!file.exists(file.bim)) stop(paste(file.bim," does not exist!",sep=""))
  file.fam=paste(file,".fam",sep="")
  if(!file.exists(file.fam)) stop(paste(file.fam," does not exist!",sep=""))
  
  fam=read.table(file.fam)
  
  index.ped=which(!is.na(match(fam[,1],pheno[,1])) & !is.na(match(fam[,2],pheno[,2])))
  if(length(index.ped)==0) stop("No overlap between the genotype and phenotype data!")
  index.pheno=match(fam[index.ped,2],pheno[,2])
  
  mypheno=pheno[index.pheno,]
  if(length(col.pheno)<=1) stop("At least two phenotypes need to be provided for each subject!")
  y=as.matrix(mypheno[,col.pheno])
  cor.y = cor(y,use="pairwise.complete.obs")
  if(sum(cor.y<=0)>0) {
    warning("At least one pair of the phenotypes is not positively correlated; consider transformation.  As an alternative, consider M-DF test implemented within library geepack.")
  }
  if(is.null(col.covar)) { 
    x=matrix(1,nrow=nrow(y),ncol=1) 
  } else {
    x=as.matrix(cbind(1,mypheno[,col.covar]))
  }
  if(is.null(col.w)) w=NULL else w=mypheno[,col.w]
  if(is.null(col.status)) status=NULL else status=mypheno[,col.status]  


  n.subject.all=nrow(fam)
  myfam=fam[index.ped,]
  names.subject=paste(as.character(myfam[,1]),as.character(myfam[,2]),sep=".")
  n.subject=length(names.subject)
  
  bim=read.table(file.bim)
  names.snp=as.character(bim[,2])
  n.snp=length(names.snp)
  
  if(ceiling(n.subject.all/4)*n.snp+3!=file.info(file.bed)$size) {
    stop(paste("The PLINK data (",file,") does not look correct!",sep=""))
  }
  
  bed.conn=file(file.bed,"rb")
  bed=readBin(bed.conn,what="raw",n=3)
  if(bed[1]!="6c" | bed[2]!="1b") {
    stop(paste("The PLINK data (",file,") needs to be v1.00 format!",sep=""))
  }
  if(bed[3]!="01") {
    stop(paste("The PLINK data (",file,") needs to be SNP-major!",sep=""))
  }
  
  bim$pvalue=NA
  bim$pvalue.common=NA
  fit=vector("list",n.snp)
  
  for(i in 1:n.snp) {
    bed = readBin(bed.conn,what="raw",n=ceiling(n.subject.all/4))
    snp = matrix(as.numeric(rawToBits(bed)),ncol=2,byrow=TRUE)[1:n.subject.all,]
    geno = 2-rowSums(snp)
    geno[snp[,1]-snp[,2]==1]=NA
    geno=geno[index.ped]
    #-----------------------------------------------------------------------
    
    fit[[i]]=SMAT(y,x,s=geno,w=w,status=status,prev=prev,working=working,conv=conv,maxiter=maxiter)
    bim$pvalue[i]=fit[[i]]$pvalue
    bim$pvalue.common[i]=fit[[i]]$pvalue.common
    
    #-----------------------------------------------------------------------
    if(verbose==TRUE) print(i)
  }
  
  close(bed.conn)
  
  return(list(pvalues=bim,fits=fit))
}
