lowerTriangle <-
function(x, diag=F) {
	x[lower.tri(x,diag=diag)]
}
